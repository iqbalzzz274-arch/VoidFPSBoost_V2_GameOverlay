# Void FPS Boost V2

Void-style Android gaming booster prototype with an in-game overlay.

### Build
Open the project folder in Android Studio, sync Gradle, then Build > Build APK(s).

### How to test
1. Install the debug APK.
2. Open Void FPS Boost.
3. Tap **ALLOW OVERLAY** and enable the permission.
4. Tap **START VOID GAME MODE**.
5. The VOID overlay appears above other apps/games.

### Important
The overlay is real. Some controls are UI placeholders for the next build. A normal Android app cannot safely force CPU/GPU overclocking or guarantee higher FPS. Real FPS measurement, screen recording, DND controls, and deeper game integration require additional Android APIs/permissions and device support.
