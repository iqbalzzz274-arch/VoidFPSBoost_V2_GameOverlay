package com.voidfpsboost

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import kotlin.math.roundToInt

class VoidOverlayService : Service() {
    private var wm: WindowManager? = null
    private var root: LinearLayout? = null
    private val handler = Handler(Looper.getMainLooper())
    private var fps = 60

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(77, Notification.Builder(this, "void")
            .setContentTitle("VOID Game Mode")
            .setContentText("Gaming overlay is active")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build())
        if (Settings.canDrawOverlays(this)) showOverlay()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val c=NotificationChannel("void","VOID Game Mode",NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
    }

    private fun label(s:String, size:Float=13f): TextView =
        TextView(this).apply { text=s; textSize=size; setTextColor(Color.WHITE); setPadding(18,10,18,10) }

    private fun button(s:String, action:()->Unit): Button =
        Button(this).apply {
            text=s; textSize=12f; setTextColor(Color.WHITE); setOnClickListener { action() }
        }

    private fun showOverlay() {
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(18,18,18,18)
            setBackgroundColor(Color.argb(235,8,9,13))
        }
        val header=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        header.addView(label("VOID • GAME BOOST",18f), LinearLayout.LayoutParams(0,-2,1f))
        header.addView(button("×"){ hideOverlay() }, LinearLayout.LayoutParams(60,60))
        root!!.addView(header)

        val stats=label("FPS 60  •  120Hz\nCPU  —   GPU  —   TEMP  system-managed\nNETWORK  — ms",17f)
        root!!.addView(stats)

        val grid=GridLayout(this).apply { columnCount=2 }
        grid.addView(button("⚡ PERFORMANCE BOOST"){ Toast.makeText(this@VoidOverlayService,"Boost mode toggled",Toast.LENGTH_SHORT).show() })
        grid.addView(button("🔕 BLOCK NOTIFICATIONS"){ Toast.makeText(this@VoidOverlayService,"Notification blocking needs system/Do Not Disturb permission.",Toast.LENGTH_SHORT).show() })
        grid.addView(button("🎥 SCREEN RECORD"){ Toast.makeText(this@VoidOverlayService,"Screen recording will be added next.",Toast.LENGTH_SHORT).show() })
        grid.addView(button("🔒 TOUCH LOCK"){ Toast.makeText(this@VoidOverlayService,"Touch lock is a planned feature.",Toast.LENGTH_SHORT).show() })
        grid.addView(button("☀ BRIGHTNESS"){ Toast.makeText(this@VoidOverlayService,"Brightness control ready for next build.",Toast.LENGTH_SHORT).show() })
        grid.addView(button("✕ CLOSE"){ stopSelf() })
        root!!.addView(grid)

        val p=WindowManager.LayoutParams(
            720, WindowManager.LayoutParams.WRAP_CONTENT,
            if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT)
        p.gravity=Gravity.CENTER
        wm!!.addView(root,p)
    }

    private fun hideOverlay() {
        root?.let { try { wm?.removeView(it) } catch(_:Exception) {} }
        root=null
    }

    override fun onDestroy() { hideOverlay(); handler.removeCallbacksAndMessages(null); super.onDestroy() }
    override fun onBind(intent: Intent?) = null
}
