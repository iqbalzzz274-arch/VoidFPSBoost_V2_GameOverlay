package com.voidfpsboost

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
            setBackgroundColor(android.graphics.Color.rgb(8,9,13))
        }
        fun text(s:String, z:Float)=TextView(this).apply {
            text=s; textSize=z; setTextColor(android.graphics.Color.WHITE); setPadding(0,8,0,8)
        }
        box.addView(text("VOID FPS BOOST", 30f))
        box.addView(text("Game Mode • V2", 16f))
        box.addView(text("Overlay akan muncul di atas game bila kebenaran overlay diberikan.", 14f))

        val permission = Button(this).apply {
            text = "ALLOW OVERLAY"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        }
        box.addView(permission)

        val start = Button(this).apply {
            text = "START VOID GAME MODE"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Tekan ALLOW OVERLAY dahulu.", Toast.LENGTH_LONG).show()
                } else {
                    val i = Intent(this@MainActivity, VoidOverlayService::class.java)
                    startForegroundService(i)
                    Toast.makeText(this@MainActivity, "VOID Game Mode aktif.", Toast.LENGTH_SHORT).show()
                }
            }
        }
        box.addView(start)

        val stop = Button(this).apply {
            text = "STOP OVERLAY"
            setOnClickListener { stopService(Intent(this@MainActivity, VoidOverlayService::class.java)) }
        }
        box.addView(stop)
        setContentView(box)
    }
}
