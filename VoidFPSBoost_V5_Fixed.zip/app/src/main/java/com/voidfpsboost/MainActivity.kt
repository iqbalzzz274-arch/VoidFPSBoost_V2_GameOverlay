package com.voidfpsboost

import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.*
import android.widget.Toast
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var dashboard: VoidDashboardView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        dashboard = VoidDashboardView(this,
            onBoost = {
                dashboard.boostActive = !dashboard.boostActive
                dashboard.invalidate()
                Toast.makeText(this, if (dashboard.boostActive) "VOID BOOST ACTIVE" else "BOOST STOPPED", Toast.LENGTH_SHORT).show()
            },
            onOverlay = {
                if (!Settings.canDrawOverlays(this)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    startForegroundService(Intent(this, VoidOverlayService::class.java))
                    Toast.makeText(this, "VOID gaming overlay aktif", Toast.LENGTH_SHORT).show()
                }
            }
        )
        setContentView(dashboard)
    }
}

private class VoidDashboardView(
    private val activity: Activity,
    private val onBoost: () -> Unit,
    private val onOverlay: () -> Unit
) : View(activity) {
    var boostActive = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val red = Color.rgb(245, 32, 32)
    private val red2 = Color.rgb(190, 20, 20)
    private val white = Color.rgb(242, 242, 246)
    private val muted = Color.rgb(150, 150, 158)
    private val panel = Color.rgb(15, 16, 20)
    private val stroke = Color.rgb(45, 46, 53)

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        c.drawColor(Color.BLACK)
        val w = width.toFloat(); val h = height.toFloat()
        val s = min(w / 720f, h / 1560f)
        c.save(); c.scale(s, s)
        val W = w / s
        drawBackground(c, W, h / s)
        drawHeader(c, W)
        drawFpsCard(c, W)
        drawStatusRow(c, W)
        drawStats(c, W)
        drawTools(c, W)
        drawNav(c, W, h / s)
        c.restore()
    }

    private fun drawBackground(c: Canvas, w: Float, h: Float) {
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = Color.rgb(55, 10, 12)
        for (i in 0..10) c.drawLine(0f, 160f + i*105f, w, 160f + i*105f, p)
        p.style = Paint.Style.FILL
        p.color = Color.rgb(22, 5, 7)
        c.drawRect(0f, 0f, 4f, h, p)
        c.drawRect(w-4f, 0f, w, h, p)
    }

    private fun drawHeader(c: Canvas, w: Float) {
        text(c, "VOID", 28f, 36f, 58f, white, true)
        text(c, "FPS BOOST", 17f, 38f, 86f, red, true)
        hexButton(c, w-110f, 38f, 48f, "◈")
        hexButton(c, w-54f, 38f, 48f, "☷")
    }

    private fun drawFpsCard(c: Canvas, w: Float) {
        val cx = w/2; val cy = 315f; val r = 145f
        p.style=Paint.Style.FILL; p.color=Color.rgb(9,9,11); c.drawCircle(cx,cy,r+20,p)
        p.style=Paint.Style.STROKE; p.strokeWidth=24f; p.color=Color.rgb(38,20,22); c.drawArc(cx-r,cy-r,cx+r,cy+r,135f,270f,false,p)
        p.color=red; p.strokeWidth=12f; c.drawArc(cx-r,cy-r,cx+r,cy+r,135f,214f,false,p)
        p.color=red2; p.strokeWidth=3f; c.drawCircle(cx,cy,r+3,p)
        textCenter(c,"FPS",cx,255f,22f,red,true)
        textCenter(c,"60",cx,340f,78f,white,true)
        textCenter(c, if (boostActive) "BOOST ACTIVE" else "STABLE",cx,386f,19f,red,true)
        textCenter(c,"REFRESH RATE",cx,425f,15f,muted,false)
        textCenter(c,"120Hz",cx,451f,25f,white,true)
        // tick marks
        p.strokeWidth=3f; p.color=Color.rgb(85,28,30)
        for(i in 0..19){ val a=Math.toRadians(135.0+i*14.2); val x1=cx+Math.cos(a)*(r+10); val y1=cy+Math.sin(a)*(r+10); val x2=cx+Math.cos(a)*(r+18); val y2=cy+Math.sin(a)*(r+18); c.drawLine(x1.toFloat(),y1.toFloat(),x2.toFloat(),y2.toFloat(),p) }
    }

    private fun drawStatusRow(c: Canvas, w: Float) {
        val y=520f; val gap=8f; val bw=(w-40f-gap*3)/4f
        val labels=arrayOf("GAME MODE","PERFORMANCE","COOLING","NETWORK")
        val vals=arrayOf("ON","MAX","ACTIVE","OPTIMAL")
        val icons=arrayOf("⌁","⚡","◉","↯")
        for(i in 0..3){ val x=20f+i*(bw+gap); card(c,x,y,bw,118f); textCenter(c,icons[i],x+bw/2,y+38,28f,red,true); textCenter(c,labels[i],x+bw/2,y+72,14f,white,true); textCenter(c,vals[i],x+bw/2,y+98,13f,red,true) }
    }

    private fun drawStats(c: Canvas, w: Float) {
        val y=670f; val gap=10f; val bw=(w-40f-gap*2)/3f
        val names=arrayOf("CPU","RAM","GPU"); val values=arrayOf("78%","62%","65%"); val subs=arrayOf("2.84 GHz","4.9 / 8.0 GB","587 MHz"); val temps=arrayOf("42°C","USED","39°C")
        for(i in 0..2){ val x=20f+i*(bw+gap); card(c,x,y,bw,300f); text(c,names[i],x+18,y+34,17f,white,true); text(c,values[i],x+bw-18,y+34,18f,red,true,Paint.Align.RIGHT); ring(c,x+bw/2,y+120,58f,0.7f); textCenter(c,subs[i],x+bw/2,y+196,17f,white,true); textCenter(c,"TEMPERATURE",x+bw/2,y+235,12f,muted,false); textCenter(c,temps[i],x+bw/2,y+263,21f, if(i==1) muted else red,true); if(i==1) button(c,x+20,y+270,bw-40,0f,"CLEAN NOW",false) }
    }

    private fun drawTools(c: Canvas, w: Float) {
        val y=995f; val gap=10f; val bw=(w-40f-gap*3)/4f
        val names=arrayOf("GAME LIBRARY","PERFORMANCE\nTWEAKS","THERMAL\nMANAGER","FPS\nMONITOR")
        val vals=arrayOf("12 GAMES  ›","TUNE  ›","COOL  ›","LIVE  ›")
        for(i in 0..3){ val x=20f+i*(bw+gap); card(c,x,y,bw,180f); textCenter(c,arrayOf("▦","☷","♨","⌁")[i],x+bw/2,y+55,34f,red,true); val lines=names[i].split("\\n"); lines.forEachIndexed{j,t->textCenter(c,t,x+bw/2,y+98+j*20,13f,white,true)}; textCenter(c,vals[i],x+bw/2,y+150,12f,red,true) }
        button(c,20f,1195f,w-40f,72f, if(boostActive) "■  STOP BOOST" else "⚡  BOOST NOW", boostActive)
        card(c,20f,1290f,w-40f,82f); text(c,"VOID BOOST",45f,1324f,17f,white,true); text(c,if(boostActive) "ACTIVE" else "READY",45f,1350f,13f,red,true); text(c,"Gaming performance profile",w-45f,1338f,13f,muted,false,Paint.Align.RIGHT)
        text(c,"OVERLAY",w-45f,1365f,12f,muted,true,Paint.Align.RIGHT)
    }

    private fun drawNav(c: Canvas,w:Float,h:Float){ val y=h-92f; card(c,16f,y,w-32f,70f); val labels=arrayOf("HOME","GAMES","TOOLS","PROFILE"); for(i in 0..3){ val x=70f+i*(w-140f)/3f; textCenter(c,arrayOf("⌂","♧","▣","◯")[i],x,y+26,23f,if(i==0) red else muted,true); textCenter(c,labels[i],x,y+51,11f,if(i==0) red else muted,true)} }

    private fun card(c:Canvas,x:Float,y:Float,w:Float,h:Float){ p.style=Paint.Style.FILL;p.color=panel;c.drawRoundRect(x,y,x+w,y+h,18f,18f,p);p.style=Paint.Style.STROKE;p.strokeWidth=1.5f;p.color=stroke;c.drawRoundRect(x,y,x+w,y+h,18f,18f,p);p.color=Color.rgb(85,16,18);c.drawLine(x+18,y,x+w-18,y,p);p.style=Paint.Style.FILL }
    private fun button(c:Canvas,x:Float,y:Float,w:Float,h:Float,label:String,active:Boolean){ val hh=if(h<=0)50f else h; p.style=Paint.Style.FILL;p.color=if(active) Color.rgb(75,8,10) else Color.rgb(24,11,13);c.drawRoundRect(x,y,x+w,y+hh,18f,18f,p);p.style=Paint.Style.STROKE;p.strokeWidth=2f;p.color=red;c.drawRoundRect(x,y,x+w,y+hh,18f,18f,p);p.style=Paint.Style.FILL;textCenter(c,label,x+w/2,y+hh/2+7,16f,if(active) white else red,true) }
    private fun ring(c:Canvas,cx:Float,cy:Float,r:Float,f:Float){p.style=Paint.Style.STROKE;p.strokeWidth=10f;p.color=Color.rgb(45,24,25);c.drawCircle(cx,cy,r,p);p.color=red;c.drawArc(cx-r,cy-r,cx+r,cy+r,-90f,360f*f,false,p);p.style=Paint.Style.FILL;}
    private fun hexButton(c:Canvas,cx:Float,cy:Float,size:Float,s:String){ card(c,cx-size/2,cy-size/2,size,size);textCenter(c,s,cx,cy+8,25f,red,true) }
    private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int,bold:Boolean,align:Paint.Align=Paint.Align.LEFT){p.style=Paint.Style.FILL;p.color=color;p.textSize=size;p.typeface=if(bold) Typeface.create("sans-serif-condensed",Typeface.BOLD) else Typeface.create("sans-serif",Typeface.NORMAL);p.textAlign=align;c.drawText(s,x,y,p)}
    private fun textCenter(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int,bold:Boolean)=text(c,s,x,y,size,color,bold,Paint.Align.CENTER)

    override fun onTouchEvent(e: android.view.MotionEvent): Boolean {
        if(e.action==MotionEvent.ACTION_UP){ val s=min(width/720f,height/1560f); val x=e.x/s; val y=e.y/s
            if(y in 1190f..1280f){ onBoost(); return true }
            if(y in 1360f..1410f){ onOverlay(); return true }
        }
        return true
    }
}
