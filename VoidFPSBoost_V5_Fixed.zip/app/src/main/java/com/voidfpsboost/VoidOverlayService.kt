package com.voidfpsboost

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import kotlin.math.min

class VoidOverlayService : Service() {
    private var wm: WindowManager? = null
    private var view: VoidOverlayView? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(77, Notification.Builder(this,"void")
            .setContentTitle("VOID Game Mode")
            .setContentText("Gaming overlay is active")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true).build())
        if(Settings.canDrawOverlays(this)) showOverlay()
    }
    private fun createChannel(){ val c=NotificationChannel("void","VOID Game Mode",NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager::class.java).createNotificationChannel(c) }
    private fun showOverlay(){
        wm=getSystemService(WINDOW_SERVICE) as WindowManager
        view=VoidOverlayView(this){ stopSelf() }
        val type=if(Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val lp=WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.MATCH_PARENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT)
        lp.gravity=Gravity.CENTER
        wm!!.addView(view,lp)
    }
    override fun onDestroy(){ view?.let{try{wm?.removeView(it)}catch(_:Exception){}};view=null;super.onDestroy() }
    override fun onBind(intent:Intent?)=null
}

private class VoidOverlayView(ctx:Context, val close:()->Unit): View(ctx){
    private val p=Paint(Paint.ANTI_ALIAS_FLAG); private val red=Color.rgb(245,28,28); private val white=Color.rgb(240,240,242); private val muted=Color.rgb(175,175,180); private val bg=Color.argb(225,5,6,9)
    override fun onDraw(c:Canvas){ super.onDraw(c); val w=width.toFloat(); val h=height.toFloat(); val s=min(w/1440f,h/900f); c.save(); c.scale(s,s); val W=w/s; val H=h/s
        p.color=Color.argb(115,0,0,0);c.drawRect(0f,0f,W,H,p)
        drawLeft(c,25f,25f,520f,H-50f); drawRight(c,W-165f,35f,140f,H-70f); drawTop(c,W); drawBottom(c,W,H); c.restore() }
    private fun panel(c:Canvas,x:Float,y:Float,w:Float,h:Float){p.style=Paint.Style.FILL;p.color=bg;c.drawRoundRect(x,y,x+w,y+h,28f,28f,p);p.style=Paint.Style.STROKE;p.strokeWidth=2f;p.color=Color.rgb(75,18,20);c.drawRoundRect(x,y,x+w,y+h,28f,28f,p);p.color=red;c.drawLine(x+25,y,x+w-25,y,p);p.style=Paint.Style.FILL}
    private fun drawLeft(c:Canvas,x:Float,y:Float,w:Float,h:Float){panel(c,x,y,w,h); text(c,"VOID",x+35,y+58,38f,white,true); text(c,"GAME BOOSTER",x+37,y+88,20f,muted,true); text(c,"⋯",x+w-115,y+62,36f,white,true); text(c,"⚙",x+w-65,y+62,30f,white,true)
        stat(c,x+28,y+120,w-56,180f); smallStats(c,x+28,y+325,w-56); ram(c,x+28,y+470,w-56,180f); modes(c,x+28,y+675,w-56); button(c,x+28,y+h-78,w-56,52f,"■  STOP BOOST") }
    private fun stat(c:Canvas,x:Float,y:Float,w:Float,h:Float){card(c,x,y,w,h);text(c,"FPS",x+25,y+40,17f,white,true);text(c,"60",x+25,y+105,72f,white,true);text(c,"FPS",x+180,y+105,28f,red,true);text(c,"STABLE",x+25,y+150,16f,red,true);text(c,"120Hz",x+w-25,y+150,17f,muted,true,Paint.Align.RIGHT);text(c,"NETWORK",x+w-145,y+40,15f,muted,true);text(c,"⌁",x+w-90,y+92,38f,red,true);text(c,"20 ms",x+w-25,y+135,16f,white,true,Paint.Align.RIGHT)}
    private fun smallStats(c:Canvas,x:Float,y:Float,w:Float){card(c,x,y,w,105f);val n=arrayOf("CPU","GPU","TEMP");val v=arrayOf("72%","68%","42°C");for(i in 0..2){val xx=x+25+i*(w-50)/3f;text(c,n[i],xx,y+35,14f,muted,true);text(c,v[i],xx,y+70,19f,white,true);p.color=red;c.drawRoundRect(xx,y+82,xx+(w-80)/3f,y+88,3f,3f,p)}}
    private fun ram(c:Canvas,x:Float,y:Float,w:Float,h:Float){card(c,x,y,w,h);text(c,"RAM",x+25,y+35,15f,muted,true);ring(c,x+82,y+92,48f,.64f);textCenter(c,"64%",x+82,y+100,24f,white,true);text(c,"64%",x+155,y+70,29f,white,true);text(c,"USED",x+155,y+98,13f,muted,true);text(c,"4.9 / 7.7 GB",x+155,y+125,15f,muted,false);button(c,x+w-185,y+62,150f,44f,"CLEAN RAM")}
    private fun modes(c:Canvas,x:Float,y:Float,w:Float){val labels=arrayOf("BOOST","BALANCED","ECO","CUSTOM");for(i in 0..3){val bw=(w-30)/4f;val xx=x+i*(bw+10);card(c,xx,y,bw,85f);textCenter(c,arrayOf("⚡","◈","◌","☷")[i],xx+bw/2,y+34,23f,if(i==0)red:muted,true);textCenter(c,labels[i],xx+bw/2,y+62,11f,white,true)}}
    private fun drawRight(c:Canvas,x:Float,y:Float,w:Float,h:Float){panel(c,x,y,w,h);val a=arrayOf("◉","♧","▣","♧","☼","▦");val b=arrayOf("PERFORMANCE","BLOCK\nNOTIFICATIONS","SCREEN\nRECORD","TOUCH\nLOCK","BRIGHTNESS\nLOCK","RECENT APPS");for(i in a.indices){val yy=y+70+i*(h-90)/6f;textCenter(c,a[i],x+w/2,yy,30f,if(i==0)red:white,true);b[i].split("\\n").forEachIndexed{j,t->textCenter(c,t,x+w/2,yy+43+j*17,11f,if(i==0)red:white,true)}}}
    private fun drawTop(c:Canvas,w:Float){textCenter(c,"VOID",w/2,50f,28f,red,true);textCenter(c,"⌄",w/2,88f,30f,white,true)}
    private fun drawBottom(c:Canvas,w:Float,h:Float){panel(c,25f,h-78,w-50,58f);text(c,"⚡",50f,h-40,24f,red,true);text(c,"VOID BOOST",82f,h-46,14f,white,true);text(c,"ACTIVE",82f,h-27,12f,red,true);text(c,"This game is being optimized",w/2,h-42,15f,white,false,Paint.Align.CENTER);text(c,"Battery: 78%",w-45,h-40,14f,white,false,Paint.Align.RIGHT)}
    private fun card(c:Canvas,x:Float,y:Float,w:Float,h:Float){p.style=Paint.Style.FILL;p.color=Color.rgb(10,10,13);c.drawRoundRect(x,y,x+w,y+h,18f,18f,p);p.style=Paint.Style.STROKE;p.strokeWidth=1f;p.color=Color.rgb(52,52,58);c.drawRoundRect(x,y,x+w,y+h,18f,18f,p);p.style=Paint.Style.FILL}
    private fun button(c:Canvas,x:Float,y:Float,w:Float,h:Float,s:String){p.style=Paint.Style.STROKE;p.strokeWidth=2f;p.color=red;c.drawRoundRect(x,y,x+w,y+h,16f,16f,p);p.style=Paint.Style.FILL;textCenter(c,s,x+w/2,y+h/2+6,15f,red,true)}
    private fun ring(c:Canvas,cx:Float,cy:Float,r:Float,f:Float){p.style=Paint.Style.STROKE;p.strokeWidth=8f;p.color=Color.rgb(50,20,22);c.drawCircle(cx,cy,r,p);p.color=red;c.drawArc(cx-r,cy-r,cx+r,cy+r,-90f,360f*f,false,p);p.style=Paint.Style.FILL}
    private fun text(c:Canvas,s:String,x:Float,y:Float,z:Float,col:Int,b:Boolean,a:Paint.Align=Paint.Align.LEFT){p.style=Paint.Style.FILL;p.color=col;p.textSize=z;p.textAlign=a;p.typeface=if(b)Typeface.create("sans-serif-condensed",Typeface.BOLD) else Typeface.DEFAULT;c.drawText(s,x,y,p)}
    private fun textCenter(c:Canvas,s:String,x:Float,y:Float,z:Float,col:Int,b:Boolean)=text(c,s,x,y,z,col,b,Paint.Align.CENTER)
    override fun onTouchEvent(e:MotionEvent):Boolean{if(e.action==MotionEvent.ACTION_UP){if(e.x<80&&e.y<80){close();return true}};return true}
}
