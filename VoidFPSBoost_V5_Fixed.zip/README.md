# VOID FPS BOOST V5

VOID × Red Magic inspired gaming dashboard and fullscreen gaming overlay.

- Dark glass / neon red gaming UI
- FPS dashboard and performance cards
- Boost mode toggle
- Overlay permission + foreground gaming overlay
- GitHub Actions build workflow

This app provides UI/overlay controls; it does not magically increase hardware FPS or overclock the device.
